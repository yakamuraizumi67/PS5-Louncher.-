# Launcher PS5 (TV Philco, Android 4.4)

- Tela inicial estilo PS5: fileira de apps, relogio, item em foco maior.
- 1o item abre o app de TV da Philco (com.tsb.tv), que volta na ultima entrada (HDMI 2 = PS5).
- Ao ligar a TV, abre o HDMI sozinho (liga/desliga no ultimo tile "Auto HDMI").

## Compilar
Suba esta pasta num repositorio do GitHub. A aba Actions gera o APK (artifact `launcher-ps5-apk`).

## Instalar na TV
    adb connect IP_DA_TV:5555
    adb install -r app-debug.apk

Aperte Home no controle e escolha "Launcher PS5" > "Sempre".
Para voltar ao antigo: Configuracoes > Aplicativos > Launcher PS5 > "Limpar padroes".
