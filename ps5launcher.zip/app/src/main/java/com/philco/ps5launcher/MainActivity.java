package com.philco.ps5launcher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    // App de TV da Philco (descoberto via ADB): abre a ultima entrada usada (HDMI 2 = PS5)
    static final String TV_PKG = "com.tsb.tv";
    static final String TV_CLS = "com.tsb.tv.Tv_strategy";

    private LinearLayout row;
    private HorizontalScrollView scroll;
    private TextView nameLabel;
    private View firstTile;
    private float d;

    private int px(int dp) { return (int) (dp * d + 0.5f); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;

        FrameLayout root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF0B1A3A, 0xFF1B3F8B, 0xFF0A1020}));

        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(26);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        cp.setMargins(0, px(24), px(40), 0);

        scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setClipChildren(false);
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        row.setPadding(px(40), px(30), px(40), px(30));
        scroll.addView(row);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL);

        nameLabel = new TextView(this);
        nameLabel.setTextColor(Color.WHITE);
        nameLabel.setTextSize(22);
        nameLabel.setText("PS5 (HDMI 2)");
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        np.setMargins(0, 0, 0, px(70));

        root.addView(scroll, sp);
        root.addView(clock, cp);
        root.addView(nameLabel, np);
        setContentView(root);

        // 1) PS5 / HDMI 2
        addTile("PS5 (HDMI 2)", 0xFF0070D1, null, "PS5\nHDMI 2", 20, new View.OnClickListener() {
            public void onClick(View v) { openHdmi(); }
        });

        // 2) Apps instalados
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(q, 0);
        Collections.sort(apps, new ResolveInfo.DisplayNameComparator(pm));
        for (ResolveInfo ri : apps) {
            if (ri.activityInfo.packageName.equals(getPackageName())) continue;
            final ComponentName cn = new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
            addTile(String.valueOf(ri.loadLabel(pm)), 0xFF2A2F3D, ri.loadIcon(pm), null, 0,
                    new View.OnClickListener() {
                        public void onClick(View v) { launch(cn); }
                    });
        }

        // 3) Liga/desliga o inicio automatico no HDMI
        final SharedPreferences prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        final TextView t = (TextView) addTile("Iniciar no HDMI ao ligar", 0xFF3A3A3A, null,
                toggleText(prefs), 16, null);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                boolean n = !prefs.getBoolean("auto_hdmi", true);
                prefs.edit().putBoolean("auto_hdmi", n).commit();
                t.setText(toggleText(prefs));
                Toast.makeText(MainActivity.this,
                        n ? "Vai abrir no HDMI ao ligar" : "Vai abrir neste launcher ao ligar",
                        Toast.LENGTH_SHORT).show();
            }
        });

        if (firstTile != null) firstTile.requestFocus();
    }

    private String toggleText(SharedPreferences p) {
        return "Auto HDMI\n" + (p.getBoolean("auto_hdmi", true) ? "ON" : "OFF");
    }

    private View addTile(final String name, final int color, Drawable icon, String text, int textSp,
                         View.OnClickListener click) {
        final View v;
        if (icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(px(18), px(18), px(18), px(18));
            v = iv;
        } else {
            TextView tv = new TextView(this);
            tv.setText(text);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(textSp);
            tv.setTypeface(Typeface.DEFAULT_BOLD);
            tv.setGravity(Gravity.CENTER);
            v = tv;
        }
        setBg(v, color, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(px(120), px(120));
        lp.setMargins(px(16), 0, px(16), 0);
        v.setLayoutParams(lp);
        v.setFocusable(true);
        v.setClickable(true);
        if (click != null) v.setOnClickListener(click);
        v.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View view, boolean has) {
                float s = has ? 1.2f : 1f;
                view.animate().scaleX(s).scaleY(s).setDuration(120).start();
                setBg(view, color, has);
                if (has) nameLabel.setText(name);
            }
        });
        row.addView(v);
        if (firstTile == null) firstTile = v;
        return v;
    }

    private void setBg(View v, int color, boolean focused) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(px(14));
        if (focused) g.setStroke(px(3), Color.WHITE);
        v.setBackground(g);
    }

    private void openHdmi() {
        launch(new ComponentName(TV_PKG, TV_CLS));
    }

    private void launch(ComponentName cn) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setComponent(cn);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Nao consegui abrir", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (firstTile != null) {
            scroll.smoothScrollTo(0, 0);
            firstTile.requestFocus();
        }
    }

    @Override
    public void onBackPressed() { /* launcher: nao sai */ }
}
