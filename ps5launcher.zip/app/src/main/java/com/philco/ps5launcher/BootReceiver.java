package com.philco.ps5launcher;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context c, Intent intent) {
        if (!c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("auto_hdmi", true)) return;
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            public void run() {
                try { Thread.sleep(6000); } catch (Exception e) { }
                try {
                    Intent i = new Intent();
                    i.setComponent(new ComponentName(MainActivity.TV_PKG, MainActivity.TV_CLS));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    c.startActivity(i);
                } catch (Exception e) { }
                pr.finish();
            }
        }).start();
    }
}
